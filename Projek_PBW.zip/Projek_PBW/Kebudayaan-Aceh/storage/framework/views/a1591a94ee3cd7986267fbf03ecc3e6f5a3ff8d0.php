<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="/CSS/registrasi.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<title>Registrasi</title>
</head>
<body style=”background-color:#FF0000;”>
<div class="container h-100">
    		<div class="row h-100">
				<div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mt-4">
							<h1 class="h2">Kebudayaan Aceh</h1>
							<p class="lead">
								Layanan Aplikasi Informasi Kebudayaan Aceh
							</p>
						</div>

						<div class="card">
							<div class="card-body">
								<div class="m-sm-4">
									<form>
										<div class="form-group">
											<label>Nama</label>
											<input class="form-control form-control-lg" type="text" name="name" placeholder="Masukkan nama">
										</div>
										<div class="form-group">
											<label>Email</label>
											<input class="form-control form-control-lg" type="text" name="company" placeholder="Masukkan email">
										</div>
										<div class="form-group">
											<label>Password</label>
											<input class="form-control form-control-lg" type="email" name="email" placeholder="masukkan password">
										</div>
										<div class="form-group">
											<label>Konfirmasi Password</label>
											<input class="form-control form-control-lg" type="password" name="password" placeholder="konfirmasi password">
										</div>
										<div class="text-center mt-3">
											<a href="index.html" class="btn btn-lg btn-primary">Daftar</a>
											<!-- <button type="submit" class="btn btn-lg btn-primary">Sign up</button> -->
										</div>
									</form>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
</body>
</html><?php /**PATH C:\Users\FITRIA\Documents\Projek_PBW\Kebudayaan-Aceh\resources\views/Registrasi.blade.php ENDPATH**/ ?>