<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Kebudayaan Aceh</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="./favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
       <link href="css/home.css" rel="stylesheet">
    <body id="page-top">
        
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="#page-top"><img src="./img/navbar.png" alt="..." /></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ms-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link" href="#SenjataAdat">Senjata Adat</a></li>
                        <li class="nav-item"><a class="nav-link" href="#AlatMusik">Alat Musik</a></li>
                        <li class="nav-item"><a class="nav-link" href="#TarianAdat">Tarian Adat</a></li>
                        <li class="nav-item"><a class="nav-link" href="#TempatWisata">Tempat Wisata</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        
        <header class="masthead">
            <div class="container">
                <div class="masthead-subheading">Kebudayaan Aceh</div>
                <div class="masthead-heading text-uppercase">WELCOME TO ACEH</div>
                <a class="btn btn-primary btn-xl text-uppercase" href="#SenjataAdat">Lanjut</a>
            </div>
        </header>
        
        <section class="page-section" id="SenjataAdat">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Senjata Adat</h2>
                </div>
                <div class="row text-center">
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                             <img class="img-fluid" src="./img/1.jpg" alt="..." />
                            <i class="fas fa-circle fa-stack-2x text-primary"></i>
                        </span>
                        <h4 class="my-3">Rencong</h4>
                        <p class="text-muted">Rencong dikenal sudah dipakai semenjak jaman Kesultanan Aceh, lebih tepatnya pada masa pemerintahan Sultan Ali Mughaya Syah</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-primary"></i>
                            <img class="img-fluid" src="./img/2.jpeg" alt="..." />
                        </span>
                        <h4 class="my-3">Siwah</h4>
                        <p class="text-muted">Pada jaman dahulu, Siwah juga dipakai sebagai alat untuk melindungi diri dan senjata untuk melawan penjajah Belanda.</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-primary"></i>
                            <img class="img-fluid" src="./img/3.jpeg" alt="..." />
                        </span>
                        <h4 class="my-3">Pedang Aceh</h4>
                        <p class="text-muted"> Senjata adat Aceh yang lain adalah Peudeung atau Pedang Aceh. Senjata tersebut biasanya dipakai sebagai senjata pelengkap saat peperangan.</p>
                    </div>
                </div>
            </div>
        </section>
       
        <section class="page-section bg-light" id="AlatMusik">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Alat Musik</h2>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-6 mb-4">
                        <!-- Portfolio item 1-->
                        <div class="AlatMusik-item">
                            <a class="AlatMusik-link" data-bs-toggle="modal" href="#portfolioModal1">
                                <div class="AlatMusik-hover">
                                    <div class="AlatMusik-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="./img/Alat/1.jpeg" alt="..." />
                            </a>
                            <div class="AlatMusik-caption">
                                <div class="AlatMusik-caption-heading">Arbab</div>
                                <div class="AlatMusik-caption-subheading text-muted">Arbab termasuk ke dalam alat musik golongan kordofon dan dimainkan dengan cara digesek</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        
                        <div class="AlatMusik-item">
                            <a class="AlatMusik-link" data-bs-toggle="modal" href="#AlatMusikModal2">
                                <div class="AlatMusik-hover">
                                    <div class="AlatMusik-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="./img/Alat/2.jpg" alt="..." />
                            </a>
                            <div class="AlatMusik-caption">
                                <div class="AlatMusik-caption-heading">Bangsi</div>
                                <div class="AlatMusik-caption-subheading text-muted"> Bangsi / Bansi Alas merupakan alat musik yang masuk kedalam golongan aerofon yang berarti alat musik yang dapat menghasilkan suara dari hembusan udara atau singkatnya ditiup</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4">
                        
                        <div class="AlatMusik-item">
                            <a class="AlatMusik-link" data-bs-toggle="modal" href="#portfolioModal3">
                                <div class="AlatMusik-hover">
                                    <div class="AlatMusik-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="./img/Alat/3.png" alt="..." />
                            </a>
                            <div class="AlatMusik-caption">
                                <div class="AlatMusik-caption-heading">Rapai</div>
                                <div class="AlatMusik-caption-subheading text-muted">Rapai juga termasuk kepada alat musik yang berkategori membranofon. Tetapi terdapat perbedaan dimana rapai dimainkan dengan cara dipukul namun langsung menggunakan tangan tanpa alat bantu</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
                        
                        <div class="AlatMusik-item">
                            <a class="AlatMusik-link" data-bs-toggle="modal" href="#portfolioModal4">
                                <div class="AlatMusik-hover">
                                    <div class="AlatMusik-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="./img/Alat/4.png" alt="..." />
                            </a>
                            <div class="AlatMusik-caption">
                                <div class="AlatMusik-caption-heading">Bereguh</div>
                                <div class="AlatMusik-caption-subheading text-muted">Bereguh umumnya digunakan untuk alat komunikasi pada saat di hutan atau tempat dimana seseorang sedang berjauhan dengan orang lain</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6 mb-4 mb-sm-0">
                       
                        <div class="AlatMusik-item">
                            <a class="AlatMusik-link" data-bs-toggle="modal" href="#portfolioModal5">
                                <div class="AlatMusik-hover">
                                    <div class="AlatMusik-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="./img/Alat/5.png" alt="..." />
                            </a>
                            <div class="AlatMusik-caption">
                                <div class="AlatMusik-caption-heading">Canang</div>
                                <div class="AlatMusik-caption-subheading text-muted">Canang atau bende adalah sejenis gong kecil, biasanya digunakan untuk mengiringi tarian-tarian tradisional Aceh</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        
                        <div class="AlatMusik-item">
                            <a class="AlatMusik-link" data-bs-toggle="modal" href="#portfolioModal6">
                                <div class="AlatMusik-hover">
                                    <div class="AlatMusik-hover-content"><i class="fas fa-plus fa-3x"></i></div>
                                </div>
                                <img class="img-fluid" src="./img/Alat/6.jpg" alt="..." />
                            </a>
                            <div class="AlatMusik-caption">
                                <div class="AlatMusik-caption-heading">Geundrang</div>
                                <div class="AlatMusik-caption-subheading text-muted">Geundrang termasuk jenis alat musik pukul, cara memainkannya adalah dengan memukul menggunakan tangan atau memakai kayu pemukul</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="page-section" id="TarianAdat">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Tarian Tradisional</h2>
                </div>
                <ul class="timeline">
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="./img/Tarian/1.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Tari Saman</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Tari Saman ditampilkan dengan cara duduk, rapi, dan berjajar beramai-ramai. Gerakan Tari Saman didominasi oleh tepukan, perpaduan antara gerakan menepuk pundak dan tangan. Gerakan tersebut diiringi dengan tempo syair yang khas dan dilakukan dengan seirama.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="./img/Tarian/2.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Tari Ratoh Jaroe</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Tari Ratoh Jaroe ini memiliki tujuan yaitu untuk menunjukan karakteristik wanita Aceh yang dikenal sangat kompak satu sama lain, pemberani dan semangat pantang menyerah. Bukan hanya itu saja, makna tari ratoh jaroe yang berasal dari Aceh ini juga menggambarkan rasa syukur, bentuk puji-pujian dan zikir kepada Tuhan Yang Maha Esa.</p></div>
                        </div>
                    </li>
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="./img/Tarian/3.jpg" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4> Tari Likok Pulo</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Tari Likok Pulo adalah sebuah tarian tradisional yang berasal dari Aceh, Indonesia. "Likok" berarti gerak tari, sementara "Pulo" berarti pulau. Gerak Tari Likok Pulo komposisinya dimulai dengan gerakan salam anggukan kepala dan tangan yang diselangi gerakan pinggul. Ritme tarian saling membentang dan seling ke kiri dan ke kanan sambil melantunkan syair-syair pujian kepada Sang Khalik yang diiringi dengan musik Rapai dan vokalis nyanyian syair Aceh. </p></div>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
        <!-- Team-->
        <section class="page-section bg-light" id="TempatWisata">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Tempat Wisata</h2>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div>
                            <img class="mx-auto rounded-circle" src="./img/Wisata/1.jpg" alt="..." />
                            <h4>Mesjid Baiturrahman</h4>
                            <p class="text-muted">Mesjid Baiturrahman merupakan peninggalan Kerajaan Aceh yang menjadi simbol agama, budaya, dan perjuangan masyarakat Aceh. Masjid Raya Baiturrahman dibangun oleh Sultan Iskandar Muda, raja Aceh periode 1607-1636, pada 1612 M. Dalam sejarahnya, masjid ini sempat dibakar Belanda, tetapi dapat selamat ketika diterjang dahsyatnya tsunami 2004.</p>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div>
                            <img class="mx-auto rounded-circle" src="./img/Wisata/2.jpg" alt="..." />
                            <h4>Museum Tsunami Aceh</h4>
                            <p class="text-muted">Museum tsunami terletak di Jalan Sultan Iskandar Muda dekat Simpang Jam dan berseberangan dengan Lapangan Blang Padang kota Banda Aceh dan di resmikan pada bulan februari tahun 2008. Tujuan dibangunnya museum ini adalah untuk mengenang gempa bumi yang mengakibatkan tsunami tahun 2004, selain itu  juga menjadi pusat pendidikan dan sebagai pusat evakuasi jika bencana tsunami sewaktu-waktu datang lagi.</p>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div>
                            <img class="mx-auto rounded-circle" src="./img/Wisata/3.jpg" alt="..." />
                            <h4>Pantai Iboih Sabang</h4>
                            <p class="text-muted">Pantai Iboih memiliki pantai pasir putih dengan air laut yang biru dimana anda dapat menikmati snorkeling dengan ratusan ikan warna-warni, berenang dan dekat dengan banyak spot snorkeling dan diving. Dikelilingi oleh hutan tropis menawarkan susasana yang luar bisasa.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
<?php /**PATH C:\Users\FITRIA\Documents\Projek_PBW\Kebudayaan-Aceh\resources\views/home.blade.php ENDPATH**/ ?>