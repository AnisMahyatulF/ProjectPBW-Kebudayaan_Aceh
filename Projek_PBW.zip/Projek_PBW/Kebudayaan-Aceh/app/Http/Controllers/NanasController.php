<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class NanasController extends Controller
{
    public function readdata()
    {
        //mau ambil data dari tabel nanas
        $nanas= DB::table('nanas')->get();

        // mengirim ke halaman nanas untuk ditampilkan data
        return view('datananas',['nanas'=>$nanas]);
    }

}
